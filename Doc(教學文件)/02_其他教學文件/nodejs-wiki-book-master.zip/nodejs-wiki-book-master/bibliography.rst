*********
參考資源
*********

Node.js 書籍
============

-  `Programming
   Node.js <http://shop.oreilly.com/product/9781934356890.do>`_, April
   2012 (est.), Travis Swicegood, Pragmatic Bookshelf
-  `The Little Book on
   CoffeeScript <http://shop.oreilly.com/product/0636920024309.do>`_,
   January 2012, Alex MacCaw, O'Reilly Media
-  `Node for Front-End
   Developers <http://shop.oreilly.com/product/0636920023258.do>`_,
   January 2012, Garann Means, O'Reilly Media
-  `Building Hypermedia APIs with HTML5 and
   Node <http://shop.oreilly.com/product/0636920020530.do>`_, November
   2011, Mike Amundsen, O'Reilly Media
-  `Node Web
   Development <http://www.packtpub.com/node-javascript-web-development/book>`_,
   August 2011, David Herron, PacktPub
-  `CoffeeScript: Accelerated JavaScript
   Development <http://pragprog.com/book/tbcoffee/coffeescript>`_, July
   2011, Trevor Burnham, Pragmatic Bookshelf
-  `Getting Started with GEO, CouchDB, and
   Node.js <http://shop.oreilly.com/product/0636920020806.do>`_, July
   2011, Mick Thompson, O'Reilly Media
-  `What Is Node? <http://shop.oreilly.com/product/0636920021506.do>`_,
   July 2011, Brett McLaughlin, O'Reilly Media
-  `Node: Up and
   Running <http://shop.oreilly.com/product/0636920015956.do>`_, May
   2011, Tom Hughes-Croucher, Mike Wilson, O'Reilly Media
-  `Hands-on Node.js <http://nodetuts.com/handson-nodejs-book.html>`_, The Node.js introduction and API reference, May 2011, Pedro Teixeira, LeanPub
-  `The Node Beginner Book <http://www.nodebeginner.org/>`_, Manuel
   Kiessling
-  `Mastering Node.js <http://visionmedia.github.com/masteringnode/>`_,
   visionmedia

Node.js 影音教學
================

-  `The Node Sessions: The Best of OSCON
   2011 <http://shop.oreilly.com/product/0636920022183.do>`_, August
   2011, O'Reilly Media (Video)
-  `Tom Hughes-Croucher on
   Node <http://shop.oreilly.com/product/0636920017080.do>`_, March
   2011, O'Reilly Media (Video)

Node.js 教學網站
================

-  `Node Tuts <http://nodetuts.com/>`_

Node.js 課程
============

-  `Introduction To
   Node.js <http://codelesson.com/courses/view/introduction-to-node-js>`_,
   Van Nguyen, CodeLesson

