.. raw:: latex

   \setcounter{secnumdepth}{-1}

****
前言
****

Node.js 是 JavaScript 程式語言的開發框架，由0.4.x至目前v0.6.0版本核心上已經有許多變更，當然目的只有一個就是讓開發變得更簡單，速度能夠更快，這是所有人奮鬥的目標。而nodeJS 華文維基平台，主力由nodeJS.tw 一群喜好javascript 開發者共同主筆，內文以中文為主，希望能夠降低開發者學習門檻，藉由我們拋磚引玉，讓更多華人開發者共同學習、討論。



.. raw:: latex

   \setcounter{secnumdepth}{1}

