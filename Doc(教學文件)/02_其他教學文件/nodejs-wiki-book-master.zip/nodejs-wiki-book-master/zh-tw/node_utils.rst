********************
Node.js 好用工具介紹
********************

log.io
=======

Real-time log monitoring in your browser

http://logio.org/

node.js (>=0.4.12 <=0.6.11)

::

    npm config set unsafe-perm true 
    npm install -g --prefix=/usr/local log.io
    log.io server start

::

    http://localhost:8998
