watch( '(.*)\.md' )  {|md| system("make all") }
